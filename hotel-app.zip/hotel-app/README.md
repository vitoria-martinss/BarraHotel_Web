# Hotel Vale Verde — Landing page + Sistema de reservas

Stack: **Node/Express + MySQL** no backend, **React (Vite)** no frontend.
Autenticação por papel (hóspede / recepcionista / admin) usando JWT.

## 1. Banco de dados

```bash
mysql -u root -p < backend/schema.sql
```

Cria o banco `hotel`, as tabelas e alguns tipos de quarto de exemplo (Standard, Luxo, Família)
já com quartos físicos cadastrados (101, 102, 201, etc).

## 2. Backend

```bash
cd backend
npm install
cp .env.example .env
```

Edite o `.env`:
- `DB_USER` / `DB_PASSWORD`: credenciais do seu MySQL local
- `JWT_SECRET`: troque por qualquer string longa e aleatória
- `ADMIN_EMAIL` / `ADMIN_SENHA`: login do admin que será criado no próximo passo

Crie o usuário admin (só precisa rodar uma vez):

```bash
npm run seed
```

Suba o servidor:

```bash
npm run dev -- --host
```

Isso sobe em `http://localhost:3001`. As imagens dos quartos ficam salvas em `backend/uploads/`
e são servidas em `http://localhost:3001/uploads/nome-do-arquivo.jpg`.

## 3. Frontend

```bash
cd frontend
npm install
npm run dev
```

Sobe em `http://localhost:5173` — já configurado com `host: true`, então funciona
também de outros dispositivos na mesma rede (`http://SEU_IP:5173`).

Se o backend estiver em outra máquina/IP, crie `frontend/.env` com:
```
VITE_API_URL=http://SEU_IP:3001
```

## Como o sistema funciona

### Área pública (landing page)
- Qualquer visitante vê os tipos de quarto, fotos, preço, descrição e capacidade.
- Pode escolher datas de check-in/check-out para ver quantos quartos de cada tipo estão livres.
- Para reservar, precisa criar conta (`/cadastro`) ou entrar (`/entrar`).

### Hóspede
- Cria conta, faz login, reserva um tipo de quarto para um período.
- O backend aloca automaticamente um quarto físico livre daquele tipo — o hóspede não escolhe
  o número do quarto, só o tipo e as datas.
- Vê suas reservas e o status de pagamento em `/minhas-reservas`.

### Recepcionista (`/funcionarios` para logar)
- Vê quais quartos estão ocupados agora, por quem, e até quando.
- Vê todas as reservas, pode marcar como concluída/cancelada e confirmar pagamento (simulado —
  não há gateway real, é só um botão "marcar como pago").
- Pode criar reservas em nome de um hóspede já cadastrado.
- Pode cadastrar hóspedes manualmente (sem senha/login) — útil para pessoas idosas ou quem não
  quer se cadastrar sozinho online.

### Admin (mesmo login de funcionário, papel diferente)
- Tudo que o recepcionista faz, mais:
- CRUD completo de tipos de quarto (nome, descrição, preço, capacidade, fotos).
- Cadastro/remoção de quartos físicos (números de quarto).
- Cadastro de novos funcionários (recepcionistas ou outros admins).

## Sobre a senha do admin inicial

Depois de rodar `npm run seed`, o login fica disponível com o e-mail/senha que você definiu
no `.env` (`ADMIN_EMAIL` / `ADMIN_SENHA`). Recomendo já entrar e, futuramente, adicionar uma
tela de "trocar minha senha" — não implementei isso para manter o escopo enxuto, mas a
estrutura de rotas já comporta essa adição facilmente.

## Pagamento

O pagamento é **simulado**: não há integração com nenhum gateway (Stripe, Mercado Pago, etc).
A recepção/admin apenas marca a reserva como "paga" manualmente depois de receber o pagamento
por fora do sistema (dinheiro, maquininha, etc). Se um dia quiser pagamento online de verdade,
me avise — dá pra plugar um gateway na rota `PUT /api/reservas/:id/pagamento` sem reestruturar
o resto do sistema.

## Publicando para acesso externo

Assim como na agenda, hoje isso roda local. Para os hóspedes reservarem de fora da sua rede,
o backend + MySQL + frontend precisam estar hospedados em algum lugar acessível pela internet
(ex: Railway, Render, uma VPS). Me avise se quiser ajuda com isso.
